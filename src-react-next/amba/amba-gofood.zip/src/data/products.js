﻿const food = 'assets/images/mie-ayam-hero.png';

export const products = [
  { id: 1, slug: 'mie-ayam-original', name: 'Mie Ayam Original', category: 'mie-ayam', categoryName: 'Mie Ayam', price: 15000, originalPrice: null, defaultWeight: '1 porsi', weights: [{ weight: '1 porsi', price: 15000 }], badge: 'Favorit', image: food, description: 'Mie kenyal dengan ayam berbumbu gurih, sayuran segar, dan taburan bawang goreng.', specialty: true },
  { id: 2, slug: 'mie-ayam-bakso', name: 'Mie Ayam Bakso', category: 'mie-ayam', categoryName: 'Mie Ayam', price: 18000, originalPrice: null, defaultWeight: '1 porsi', weights: [{ weight: '1 porsi', price: 18000 }], badge: 'Paling dicari', image: food, description: 'Mie ayam gurih dengan bakso sapi dan kuah hangat yang nikmat.', specialty: true },
  { id: 3, slug: 'mie-ayam-bakso-pangsit', name: 'Mie Ayam Bakso & Pangsit', category: 'mie-ayam', categoryName: 'Mie Ayam', price: 22000, originalPrice: null, defaultWeight: '1 porsi', weights: [{ weight: '1 porsi', price: 22000 }], badge: 'Komplet', image: food, description: 'Semangkuk lengkap mie ayam dengan bakso, pangsit, sayuran, dan kuah kaldu.', specialty: true },
  { id: 4, slug: 'mie-ayam-pangsit', name: 'Mie Ayam Pangsit', category: 'mie-ayam', categoryName: 'Mie Ayam', price: 18000, originalPrice: null, defaultWeight: '1 porsi', weights: [{ weight: '1 porsi', price: 18000 }], badge: 'Gurih', image: food, description: 'Mie ayam dengan pangsit lembut, ayam berbumbu, dan kuah kaldu hangat.', specialty: true },
  { id: 5, slug: 'bakso-kuah', name: 'Bakso Kuah', category: 'bakso', categoryName: 'Bakso', price: 15000, originalPrice: null, defaultWeight: '1 porsi', weights: [{ weight: '1 porsi', price: 15000 }], badge: 'Hangat', image: food, description: 'Bakso kenyal dalam kuah kaldu hangat, cocok dinikmati kapan saja.', specialty: false },
  { id: 6, slug: 'bakso-urat', name: 'Bakso Urat', category: 'bakso', categoryName: 'Bakso', price: 18000, originalPrice: null, defaultWeight: '1 porsi', weights: [{ weight: '1 porsi', price: 18000 }], badge: 'Favorit', image: food, description: 'Bakso urat dengan tekstur mantap, disajikan bersama kuah kaldu dan pelengkap.', specialty: false },
  { id: 7, slug: 'es-teh-manis', name: 'Es Teh Manis', category: 'minuman', categoryName: 'Minuman', price: 5000, originalPrice: null, defaultWeight: '1 gelas', weights: [{ weight: '1 gelas', price: 5000 }], badge: 'Segar', image: food, description: 'Teh manis dingin sebagai teman makan mie ayam dan bakso.', specialty: false },
  { id: 8, slug: 'es-jeruk', name: 'Es Jeruk', category: 'minuman', categoryName: 'Minuman', price: 8000, originalPrice: null, defaultWeight: '1 gelas', weights: [{ weight: '1 gelas', price: 8000 }], badge: 'Segar', image: food, description: 'Minuman jeruk dingin dengan rasa segar untuk melengkapi santapan.', specialty: false },
];

export const categories = [
  { slug: 'all', name: 'Semua Menu' },
  { slug: 'mie-ayam', name: 'Mie Ayam' },
  { slug: 'bakso', name: 'Bakso' },
  { slug: 'minuman', name: 'Minuman' },
];

