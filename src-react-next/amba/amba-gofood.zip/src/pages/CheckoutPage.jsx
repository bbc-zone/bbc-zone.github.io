import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { Breadcrumb, PageHero } from '../components/Shared.jsx';
import { CartService } from '../services/CartService.js';

const gofood = 'https://gofood.co.id/serang/restaurant/mie-ayam-bakso-amba-jl-sman-1-pandeglang-5a291b0c-585e-40c3-a2a6-e5a66f29a013';

export default function CheckoutPage() {
  const [items,setItems]=useState(CartService.getItems()); useEffect(()=>{const sync=()=>setItems(CartService.getItems());window.addEventListener('ln-cart-change',sync);return()=>window.removeEventListener('ln-cart-change',sync);},[]);
  const subtotal=items.reduce((s,x)=>s+x.price*x.quantity,0);
  return <main><PageHero title="Lanjutkan Pesanan" description="Konfirmasi menu dan selesaikan pemesanan melalui halaman GoFood Mie Ayam Bakso Amba."/><div className="ln-container page-container"><Breadcrumb items={[{label:'Beranda',to:'/'},{label:'Keranjang',to:'/keranjang'},{label:'Pemesanan'}]}/>{!items.length?<div className="ln-empty-state"><h2 className="ln-empty-state-title">Keranjangmu kosong</h2><Link to="/katalog" className="ln-btn ln-btn-primary">Pilih menu</Link></div>:<div className="checkout-layout"><section className="ln-checkout-section"><h2>Pesananmu</h2><p>Daftar di bawah adalah ringkasan pilihan dari website ini. Harga dan ketersediaan dapat berbeda di GoFood.</p>{items.map((x)=><div className="summary-row" key={x.key}><span>{x.name}<small>{x.weight} × {x.quantity}</small></span><strong>Rp {(x.price*x.quantity).toLocaleString('id-ID')}</strong></div>)}<div className="summary-total"><span>Perkiraan subtotal</span><strong>Rp {subtotal.toLocaleString('id-ID')}</strong></div><p className="checkout-hint">Pemesanan, ongkir, pembayaran, dan konfirmasi pesanan ditangani di GoFood.</p><a className="ln-btn ln-btn-whatsapp ln-btn-lg" href={gofood} target="_blank" rel="noreferrer">Buka GoFood untuk Memesan ↗</a></section><aside className="ln-summary-card"><h2>Lokasi kedai</h2><p>Mie Ayam Bakso Amba</p><p>Jl. SMAN 1 Pandeglang<br/>Pandeglang, Banten</p><a href={gofood} target="_blank" rel="noreferrer">Cek detail di GoFood ↗</a></aside></div>}</div></main>;
}
